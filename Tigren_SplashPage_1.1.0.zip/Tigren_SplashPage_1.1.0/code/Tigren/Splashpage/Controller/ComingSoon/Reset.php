<?php

namespace Tigren\SplashPage\Controller\ComingSoon;

class Reset extends \Magento\Framework\App\Action\Action
{
    protected $scopeConfig;
    protected $request;
    protected $resultJsonFactory;
    /**
     * Path to store files
     *
     * @var \Magento\Framework\Filesystem\Directory\WriteInterface
     */
    protected $flagDir;
    private $maintenanceMode;
    private $helper;

    public function __construct(

        \Tigren\SplashPage\Helper\Data $helper,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Config\Model\ResourceModel\Config $resourceConfig,

        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Filesystem\Driver\File $file)
    {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->helper = $helper;
        $this->_resourceConfig = $resourceConfig;
        $this->scopeConfig = $scopeConfig;
        parent::__construct($context);
    }

    public function execute()
    {

        $maintenanceFile = 'var/.maintenance.flag';
        if (file_exists($maintenanceFile)) {
            unlink($maintenanceFile);

        }

        try {

            $model = $this->_objectManager->create('Tigren\SplashPage\Model\Updateconfig');
            $data = $model->getCollection()
                ->addFieldToFilter('path', array('eq' => 'comingsoonsection/comingsoon_group/status'));
            $array = $data->getData();
            $config_id = $array[0]['config_id'];
            $model2 = $this->_objectManager->create('Tigren\SplashPage\Model\Updateconfig')->load($config_id);
            $model2->setValue(0);
            $model2->save();
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addException(
                $e,
                __('%1', $e->getMessage())
            );
        }


    }


}
