<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Tigren_SplashPage',
    __DIR__
);
