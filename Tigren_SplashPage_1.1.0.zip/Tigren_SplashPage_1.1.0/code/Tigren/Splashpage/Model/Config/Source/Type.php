<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\SplashPage\Model\Config\Source;

class Type implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {

        return [
            ['value' => 0, 'label' => __('Image')],
            ['value' => 1, 'label' => __('Slider')],
            ['value' => 2, 'label' => __('Video')],
        ];
    }
}
