<?php

namespace Tigren\SplashPage\Model;

class Updateconfig extends \Magento\Framework\Model\AbstractModel
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {


        $this->_init('Tigren\SplashPage\Model\ResourceModel\Updateconfig');
    }
}
