<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\SplashPage\App;

class SplashPage extends \Magento\Framework\App\Http implements \Magento\Framework\AppInterface
{
    public function launch()
    {
        return $this->_response;
    }

    public function catchException(\Magento\Framework\App\Bootstrap $bootstrap, \Exception $exception)
    {
        return false;
    }
}
