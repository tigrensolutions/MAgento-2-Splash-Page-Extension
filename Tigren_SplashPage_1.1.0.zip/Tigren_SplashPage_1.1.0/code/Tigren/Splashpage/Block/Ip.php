<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\SplashPage\Block;

class Ip extends \Magento\Config\Block\System\Config\Form\Field
{
    private $helper;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param array $data
     * @param \Tigren\SplashPage\Helper\Data $helper
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Tigren\SplashPage\Helper\Data $helper
    )
    {
        parent::__construct($context);
        $this->helper = $helper;
    }

    public function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $baseURL = $this->getBaseUrl();
        $html = $element->getElementHtml();
        $html .= '<script type="text/javascript">
            require(["jquery"], function () {
                jQuery(document).ready(function () {
                	if(jQuery.trim(jQuery("#' . $element->getHtmlId() . '").val())=="")
                    	jQuery("#' . $element->getHtmlId() . '").val("' . $this->helper->getRemoteAddress() . '");
                });
            });
            </script>';
        return $html;
    }
}
