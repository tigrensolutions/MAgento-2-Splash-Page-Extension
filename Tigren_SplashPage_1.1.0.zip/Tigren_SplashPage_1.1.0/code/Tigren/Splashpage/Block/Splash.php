<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */
namespace Tigren\SplashPage\Block;
class Splash extends \Magento\Framework\View\Element\Template
{
    protected $_template = 'Tigren_SplashPage::landingpage.phtml';
    protected $_responseFactory;
    protected $_splashpageHelper;
    public function __construct(
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Tigren\SplashPage\Helper\Data $splashpageHelper,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    )
    {
        $this->_responseFactory = $responseFactory;
        
        $this->_splashpageHelper = $splashpageHelper;
        $this->_layoutConfig = $context->getLayout();
        parent::__construct($context, $data);
    }

    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    public function getAjaxUrl()
    {
        return $this->getUrl("splashpage/comingsoon/reset"); // Controller Url
    }

    public function getSplashImage()
    {
        $defaultImage = $this->getScopeConfig('comingsoonsection/general/splashimage');
        if ($defaultImage && $this->_splashpageHelper->getImageUrl($defaultImage, 'comingsoon/')) {
            $avatarUrl = $this->_splashpageHelper->getImageUrl($defaultImage, 'comingsoon/');
        } else {
            $avatarUrl = '';
        }

        return $avatarUrl;
    }

    public function getScopeConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}

