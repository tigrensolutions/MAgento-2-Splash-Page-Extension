<?php

namespace Tigren\SplashPage\Plugin;

class Homepage extends \Magento\Cms\Controller\Index\Index
{
    protected $_scopeConfig;
    protected $pageRepository;
    protected $storeManager;
    protected $resultPageFactory;
    protected $_responseFactory;
    public function __construct(
         \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Cms\Api\PageRepositoryInterface $pageRepository,
        \Magento\Framework\Controller\Result\ForwardFactory $resultForwardFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig)
    {
         $this->_responseFactory = $responseFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->storeManager = $storeManager;
        $this->pageRepository = $pageRepository;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $resultForwardFactory);
    }

    /**
     * @param \Magento\Checkout\Controller\Index\Index $subject
     * @param \Closure $proceed
     * @return $this|\Magento\Framework\View\Result\Page
     */
    public function aroundExecute(\Magento\Cms\Controller\Index\Index $subject, \Closure $proceed)
    {
        if ($this->getScopeConfig('comingsoonsection/general/cms') && $this->getScopeConfig('comingsoonsection/general/cms') == 'home') {
           $redirectUrl = $this->_url->getUrl() . 'home';
            $this->_responseFactory->create()->setRedirect($redirectUrl)->sendResponse();
        } else {
            $result = $proceed();
            return $result;
        }
    }
    public function getScopeConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}