<?php

namespace Tigren\SplashPage\Plugin;

class Updatelink extends \Magento\Cms\Controller\Page\View
{
    protected $_scopeConfig;
    protected $pageRepository;
    protected $storeManager;
    protected $resultPageFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Cms\Api\PageRepositoryInterface $pageRepository,
        \Magento\Framework\Controller\Result\ForwardFactory $resultForwardFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig)
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->storeManager = $storeManager;
        $this->pageRepository = $pageRepository;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $resultForwardFactory);
    }

    /**
     * @param \Magento\Checkout\Controller\Index\Index $subject
     * @param \Closure $proceed
     * @return $this|\Magento\Framework\View\Result\Page
     */
    public function aroundExecute(\Magento\Cms\Controller\Page\View $subject, \Closure $proceed)
    {
        $pageId = $subject->getRequest()->getParam('page_id', $subject->getRequest()->getParam('id', false));
        $page = $this->pageRepository->getById($pageId);
        $url = $page->getIdentifier();
        if ($this->getScopeConfig('comingsoonsection/general/cms') && $this->getScopeConfig('comingsoonsection/general/cms') == $url) {

            $resultPage = $this->resultPageFactory->create();
            $resultPage->getLayout()->getUpdate()->addHandle('splashpage_cms_landingpage');
            return $resultPage;
        } else {
            $result = $proceed();
            return $result;
        }
    }

    public function getScopeConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}