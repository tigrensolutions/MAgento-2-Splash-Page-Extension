<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\SplashPage\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Data
 * @package Tigren\SplashPage\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     *
     */
    const XML_PATH_HELLOWORLD = 'comingsoonsection/';
    /**
     * Maintenance flag dir
     */
    const PUB = DirectoryList::PUB;
    /**
     * @var
     */
    protected $pageFactory;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var
     */
    protected $_request;
    /**
     * @var
     */
    protected $objectManager;
    /**
     * @var \Magento\Framework\App\MaintenanceMode
     */
    private $maintenanceMode;
    /**
     * @var \Magento\Framework\Filesystem
     */
    private $fileSystem;
    /**
     * Path to store files
     *
     * @var \Magento\Framework\Filesystem\Directory\WriteInterface
     */
    private $pubDir;
    /**
     * @var \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress
     */
    private $remoteAddress;

    /**
     * Initialize dependencies.
     *
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Filesystem $fileSystem,
        \Magento\Framework\App\MaintenanceMode $maintenanceMode
    )
    {
        parent::__construct($context);
        $this->maintenanceMode = $maintenanceMode;
        $this->fileSystem = $fileSystem;
        $this->_objectManager = $objectManager;
        $this->_storeManager = $storeManager;
        $this->pubDir = $this->fileSystem->getDirectoryWrite(self::PUB);
        $this->remoteAddress = $context->getRemoteAddress();
    }

    /**
     * @param $config_path
     * @return mixed
     */
    public function getConfig($config_path)
    {
        return $this->scopeConfig->getValue(
            $config_path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return bool
     */
    public function showSplashpage()
    {
        if (!$this->enableSplashpage()) {
            return false;
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cookie = $objectManager->get(
            'Tigren\SplashPage\Cookie\Custom'
        )->set("custom_data", 3600);

        if ($cookie && $cookie == 'splashpage') {
            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    public function enableSplashpage()
    {
        return (bool)$this->scopeConfig->getValue('comingsoonsection\general\enable_in_frontend', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getSplashpageRouter()
    {
        $storeId = $this->_storeManager->getStore()->getId();
        return $this->scopeConfig->getValue('comingsoonsection\general\cms', \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);

    }

    /**
     * @return mixed
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCookie()
    {
        $storeId = $this->_storeManager->getStore()->getId();
        return $this->scopeConfig->getValue('tigren\comingsoonsection\cookie', \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);

    }

    /**
     * @param $imageName
     * @param $dir
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getImageUrl($imageName, $dir)
    {
        $path = $this->fileSystem->getDirectoryRead(
            DirectoryList::MEDIA
        )->getAbsolutePath($dir);
        if (file_exists($path . $imageName)) {
            $path = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
            return $path . $dir . $imageName;
        } else {
            return '';
        }
    }

    /**
     * Toggles maintenance mode to $ison value
     *
     * @param  boolean $ison
     * @return boolean
     */

    public function set($ison)
    {
        return $this->maintenanceMode->set($ison);
    }

    /**
     * Sets white list addresses equal to $whitelist
     *
     * @param  string $whitelist
     * @return boolean
     */
    public function setAddresses($whitelist)
    {
        $whitelist = preg_replace('/\s+/', '', $whitelist);
        return $this->maintenanceMode->setAddresses($whitelist);
    }

    /**
     * Returns string of white list IP addresses
     *
     * @return string
     */
    public function getWhiteList()
    {
        $whiteList = $this->maintenanceMode->getAddressInfo();
        if ($whiteList) {
            return implode(', ', $whiteList);
        }
        return null;
    }

    /**
     * Sets content for 503.pthml
     *
     * @param  string
     * @return boolean
     */

    public function setErrorHtml($errorHtml)
    {
        $message = '';
        if ($errorHtml) {
            $file = $this->pubDir->openFile('/errors/maintenancemode/503.phtml', 'w');
            try {
                $file->lock();
                try {
                    $message = $this->pubDir->writeFile("errors/maintenancemode/503.phtml", $errorHtml);
                } finally {
                    $file->unlock();
                }
            } finally {
                $file->close();
            }
        }
        return $message;
    }

    /**
     * @return string
     */
    public function getRemoteAddress()
    {
        return $this->remoteAddress->getRemoteAddress();
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function setPageHtml()
    {

        $message = '';
        $advPageHtml = '<!doctype html>
        <html xmlns="http://www.w3.org/1999/xhtml" >
        <head>
            <title>Coming Soon</title>
            <base href="<?php echo $this->getViewFileUrl()?>" />
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <meta name="robots" content="*"/>
            <link rel="stylesheet" href="css/styles.css" type="text/css" />
            <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
            <link rel="stylesheet" href="css/jquery.countdown.css" type="text/css" />
            <link rel="stylesheet" href="css/flexslider.css" type="text/css" />
            <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
            <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
            <script src="js/jquery-2.1.0.min.js" type="text/javascript"></script>
            <script src="js/bootstrap.min.js" type="text/javascript"></script>
            <script src="js/jquery.flexslider-min.js" type="text/javascript"></script>    
            <script src="js/jquery.plugin.min.js" type="text/javascript"></script>
            <script src="js/jquery.countdown.min.js" type="text/javascript"></script>    
            <script type="text/javascript">
                $(document).ready(function() {
                    $(\'.flexslider\').flexslider({
                        controlNav: false,
                        directionNav: false,
                        slideshowSpeed: 2000
                    });
                });
            </script>
        </head>
        <body>
            <main class="page-main">
                <?php require_once $contentTemplate;

                 ?>
            </main>
        </body>
        </html>';
        $file = $this->pubDir->openFile('/errors/maintenancemode/page.phtml', 'w');
        try {
            $file->lock();
            try {
                $message = $this->pubDir->writeFile("errors/maintenancemode/page.phtml", $advPageHtml);
            } finally {
                $file->unlock();
            }
        } finally {
            $file->close();
        }


        return $message;
    }


    /**
     * @param $code
     * @param null $storeId
     * @return mixed
     */
    public function getGeneralConfig($code, $storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_HELLOWORLD . $code, $storeId);
    }

    /**
     * @param $field
     * @param null $storeId
     * @return mixed
     */
    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field, ScopeInterface::SCOPE_STORE, $storeId
        );
    }

    /**
     * @param $endDate
     * @param $baseUrl
     * @return int
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function setAdvPageHtml($endDate, $baseUrl)
    {
        $date = '';
        if (trim($endDate) != '') {
            $date = explode('/', $endDate);
            $day = (int)$date[0];
            $month = (int)$date[1];
            $year = $date[2];
            $ymd = $year . '-' . $month . '-' . $day;
            $date = date('d F Y', strtotime($ymd));
        }
        $file = $this->pubDir->openFile('/errors/maintenancemode/page.phtml', 'w');
        try {
            $file->lock();
            try {
                $message = $this->pubDir->writeFile("errors/maintenancemode/page.phtml", $date);
            } finally {
                $file->unlock();
            }
        } finally {
            $file->close();
        }
        return $message;
    }


    /**
     * @param $layout
     * @param $type
     * @param $endDate
     * @return string
     */
    public function getLayoutHtml($layout, $type, $endDate)
    {
        $layoutHtml = '';
        $layoutHtml .= $this->getSplashPagePart($layout, $endDate);
        switch ($type) {
            case 0:
            case 1:
                $layoutHtml .= '<div>{slider}</div>';
                break;
            case 2:
                $layoutHtml .= '<div>{video}</div>';
                break;
        }

        $layoutHtml .= $this->getSocialLink($layout);
        return $layoutHtml;
    }

    /**
     * @param $layout
     * @param $endDate
     * @return string
     */
    public function getSplashPagePart($layout, $endDate)
    {
        $comingSoonHtml = '';
        switch ($layout) {
            case 0:
                $comingSoonHtml =
                    '<div class="cont">
                    <div class="row">
                        <div class="col-md-12 comingsoon">
                            <h1>{heading_text}</h1>
                            <h2>{text}</h2>';
                if (trim($endDate) != '') {
                    $comingSoonHtml .= '{countdown}';
                }
                $comingSoonHtml .=
                    '</div>                 
                    </div>';
                break;
            case 1:
                $comingSoonHtml =
                    '<div class="cont">
                    <div class="row">
                        <div class="col-md-6 comingsoon">
                            <h1>{heading_text}</h1>
                            <h2>{text}</h2>';
                if (trim($endDate) != '') {
                    $comingSoonHtml .= '{countdown}';
                }
                $comingSoonHtml .=
                    '</div>';
                $comingSoonHtml .=
                    '<div class="col-md-6">&nbsp;</div>
                    </div>';
                break;
            case 2:
                $comingSoonHtml =
                    '<div class="cont">
                    <div class="row">
                        <div class="col-md-6">&nbsp;</div>';
                $comingSoonHtml .=
                    '<div class="col-md-6 comingsoon">
                            <h1>{heading_text}</h1>
                            <h2>{text}</h2>';
                if (trim($endDate) != '') {
                    $comingSoonHtml .= '{countdown}';
                }
                $comingSoonHtml .=
                    '</div>
                    </div>';
                break;
            case 3:
                $comingSoonHtml =
                    '<div class="cont2">
                    <div class="row">
                        <div class="col-md-6 comingsoon">
                            <h1>{heading_text}</h1>
                            <h2>{text}</h2>';
                if (trim($endDate) != '') {
                    $comingSoonHtml .= '{countdown}';
                }
                $comingSoonHtml .=
                    '</div>';
                break;
        }
        return $comingSoonHtml;
    }

    /**
     * @param $layout
     * @return string
     */
    public function getSocialLink($layout)
    {
        $sociallinkHtml = '';
        switch ($layout) {
            case 0:
                $sociallinkHtml =
                    '<div class="row">
                    <div class="col-md-12">{sociallink}</div>
                </div>
                </div>';
                break;
            case 1:
                $sociallinkHtml =
                    '<div class="row">
                    <div class="col-md-6">{sociallink}</div>
                    <div class="col-md-6">&nbsp;</div>
                </div>
                </div>';
                break;
            case 2:
                $sociallinkHtml =
                    '<div class="row">
                    <div class="col-md-6">&nbsp;</div>
                    <div class="col-md-6">{sociallink}</div>                 
                </div>
                </div>';
                break;
            case 3:
                $sociallinkHtml =
                    '<div class="col-md-6">
                &nbsp;
                </div>
                <div class="col-md-6">
                    {sociallink}
                </div>
                </div>
                </div>';
                break;
        }
        return $sociallinkHtml;
    }
}
