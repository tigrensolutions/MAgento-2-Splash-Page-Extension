<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\SplashPage\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Session\SessionManagerInterface;

class ControllerActionPredispatch implements ObserverInterface
{
    const CLAY_COOKIE_NAME = 'splashpage';
    const CLAY_COOKIE_DURATION = 5000;
    protected $_cookieManager;
    protected $_cookieMetadataFactory;
    protected $storeManager;
    protected $_scopeConfig;
    protected $_objectManager;
    protected $response;
    protected $_splashpageHelper;
    protected $urlBuilder;
    protected $_url;
    protected $_responseFactory;
    protected $_urlInterface;
    protected $_cookie;
    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     */
    public function __construct(
        \Magento\Framework\UrlInterface $url,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Magento\Framework\App\Response\Http $response,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Tigren\SplashPage\Helper\Data $splashpageHelper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        SessionManagerInterface $sessionManager
    )
    {
        $this->_cookieManager = $cookieManager;
        $this->_cookieMetadataFactory = $cookieMetadataFactory;
        $this->_responseFactory = $responseFactory;
        $this->_url = $url;
        $this->_response = $response;
        $this->_splashpageHelper = $splashpageHelper;
        $this->_scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_sessionManager = $sessionManager;
    }

    /**
     * customer register event handler
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     *
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $metadata = $this->_cookieMetadataFactory
            ->createPublicCookieMetadata()
            ->setDuration(self::CLAY_COOKIE_DURATION);

        $this->_cookieManager->setPublicCookie(
            self::CLAY_COOKIE_NAME,
            'SplashPage',
            $metadata
        );
        $request = $observer->getEvent()->getControllerAction()->getRequest();
        $routeName = $request->getRouteName();

        if ($this->_scopeConfig->getValue('comingsoonsection/general/cookie', \Magento\Store\Model\ScopeInterface::SCOPE_STORE) != 0) {
            if ($routeName == 'splashpage') {
                $redirectUrl = $this->_url->getUrl();
                $this->_responseFactory->create()->setRedirect($redirectUrl)->sendResponse();
            }
        }
        $cookieValue = $this->_cookieManager->getCookie(\Tigren\SplashPage\Controller\Index\Index::CLAY_COOKIE_NAME);

        if ($this->_scopeConfig->getValue('comingsoonsection/general/enable_in_frontend', \Magento\Store\Model\ScopeInterface::SCOPE_STORE) == 1) {
            if ($routeName == 'cms') {
                $requestString = ltrim($request->getRequestString(), '/');
                $splashPageRequest = $this->_splashpageHelper->getSplashpageRouter();
                $splashBeforeUrl = $this->_storeManager->getStore()->getBaseUrl() . $requestString;
                //$this->catalogSession->getMyValue($splashBeforeUrl);
                if (!$cookieValue && $cookieValue == 0) {
                    $redirectUrl = $this->_url->getUrl() . 'splashpage';
                    $this->_responseFactory->create()->setRedirect($redirectUrl)->sendResponse();
                    return;
                } elseif ($routeName == 'splashpage') {
                    $redirectUrl = $this->_url->getUrl();
                    $this->_responseFactory->create()->setRedirect($redirectUrl)->sendResponse();
                    return;
                } else {
                    return;
                }
            }
        }

        if ($this->_scopeConfig->getValue('comingsoonsection/general/landingpage', \Magento\Store\Model\ScopeInterface::SCOPE_STORE)) {
            if ($routeName != 'splashpage' || $routeName == 'cms') {
                $redirectUrl = $this->_url->getUrl() . 'splashpage/landing';
                $this->_responseFactory->create()->setRedirect($redirectUrl)->sendResponse();
                return;
            }
        }
        else {
            return;
        }
    }
}
