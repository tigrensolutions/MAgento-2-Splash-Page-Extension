<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */
namespace Tigren\SplashPage\Observer;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
class ConfigObserver implements ObserverInterface
{
    private $scopeConfig;
    private $maintenanceMode;
    private $helper;
    private $storeManager;
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Tigren\SplashPage\Helper\Data $helper,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->helper = $helper;
        $this->storeManager = $storeManager;
    }
    public function execute(EventObserver $observer)
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $status = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/status', $storeScope);
        $headingText = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/head_text', $storeScope);
        $text = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/text', $storeScope);
        $layout = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/layout', $storeScope);
        $endDate = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/end_date', $storeScope);
        $whitelistIp = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/whitelist_ip', $storeScope);
        $type = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/type', $storeScope);
        $image = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/image', $storeScope);
        $image2 = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/image2', $storeScope);
        $image3 = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/image3', $storeScope);
        $video = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/video', $storeScope);
        $sociallinkStatus = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/sociallink_status', $storeScope);
        $facebookLink = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/facebook', $storeScope);
        $googleplusLink = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/googleplus', $storeScope);
        $youtubeLink = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/youtube', $storeScope);
        $linkedinLink = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/linkedin', $storeScope);
        $twitterLink = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/twitter', $storeScope);
        $instagramLink = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/instagram', $storeScope);
        $pinterestLink = $this->scopeConfig->getValue('comingsoonsection/comingsoon_group/pinterest', $storeScope);

        if (trim($whitelistIp) == '') {
            $whitelistIp = $this->helper->getRemoteAddress();
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
        $redirect = $storeManager->getStore()->getBaseUrl();
        $this->helper->set($status);
        $this->helper->setAddresses($whitelistIp);
        $baseUrl = $this->storeManager->getStore()->getBaseUrl();
        $mediaUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        if ($layout != 4) {
            $this->helper->setPageHtml();
            $layoutHtml = $this->helper->getLayoutHtml($layout, $type, $endDate);
            $layoutHtml = str_replace("{text}", $text, $layoutHtml);
            $layoutHtml = str_replace("{heading_text}", $headingText, $layoutHtml);
            if (($type == 1 || $type == 0) && trim($image) != '' || (trim($image2) != '' || trim($image3) != '')) { //slider
                $slider = '
                <div class="flexslider">';
                $slider .= '
                <ul class="slides">';
                $slider .= '
                <li>';
                $slider .= '<img src="' . $mediaUrl . 'comingsoon/' . $image . '"/>';
                $slider .= '</li>';
                if ($type == 1) {
                    if (trim($image2) != '') {
                        $slider .= '
                        <li>';
                        $slider .= '<img src="' . $mediaUrl . 'comingsoon/' . $image2 . '"/>';
                        $slider .= '</li>';
                    }
                    if (trim($image3) != '') {
                        $slider .= '
                        <li>';
                        $slider .= '<img src="' . $mediaUrl . 'comingsoon/' . $image3 . '"/>';
                        $slider .= '</li>';
                    }
                }
                $slider .= "
                </ul>";
                $slider .= '
                </div>';
                $layoutHtml = str_replace("{slider}", $slider, $layoutHtml);
            } else {
                $layoutHtml = str_replace("{slider}", '', $layoutHtml);
            }

            if ($type == 2) { //video
                $videohtml = '
                <div class="flexslider">';
                $videohtml .= '
                <ul class="slides">';
                $videohtml .= '
                <li><video autoplay="" loop="" id="vid">
                   <source src="' . $mediaUrl . 'comingsoon/' . $video . '" >
                </video></li>';
                $videohtml .= "
                </ul>";
                $videohtml .= '
                </div>';
                $layoutHtml = str_replace("{video}", $videohtml, $layoutHtml);
            }

            if (trim($endDate) != '') {
                $countDown = '<div id="countdown"></div>';
                $layoutHtml = str_replace("{countdown}", $countDown, $layoutHtml);
                $date = strtotime($endDate);
                $endDateArr = explode(' ', $endDate);
                $day = (int)$endDateArr[0];
                if ($endDateArr[1] == 'Jan') {
                    $month = 1;
                } elseif ($endDateArr[1] == 'Feb') {
                    $month = 2;
                } elseif ($endDateArr[1] == 'Mar') {
                    $month = 3;
                } elseif ($endDateArr[1] == 'Apr') {
                    $month = 4;
                } elseif ($endDateArr[1] == 'May') {
                    $month = 5;
                } elseif ($endDateArr[1] == 'Jun') {
                    $month = 6;
                } elseif ($endDateArr[1] == 'Jul') {
                    $month = 7;
                } elseif ($endDateArr[1] == 'Aug') {
                    $month = 8;
                } elseif ($endDateArr[1] == 'Sep') {
                    $month = 9;
                } elseif ($endDateArr[1] == 'Oct') {
                    $month = 10;
                } elseif ($endDateArr[1] == 'Nov') {
                    $month = 11;
                } elseif ($endDateArr[1] == 'Dec') {
                    $month = 12;
                }

                $year = $endDateArr[2];

                $layoutHtml .= "<script>
                $(document).ready(function() {
                 
                    // Counter
                    var year =  " . $year . ";
                    var month = " . $month . ";
                    var day = " . $day . "; 
                    var hours = 0;
                    var minutes = 0;
                    
                    var finalTime = new Date(year, month-1, day, hours, minutes);
                    finalTime.setDate(finalTime.getDate()); 

                        var date = " . $date . ";
                        
                        
                    	var currentDate = " . time() . ";
                    	
                if(date < currentDate) { 
              
                } else {
                    $('#countdown').countdown({until: finalTime, padZeroes: true});
                }
                });
                </script>";
            }
            if ($sociallinkStatus == 1) {
                $sociallink = '';
                $sociallink .= '<div class="sociallink">';
                if ($facebookLink != '') {
                    $sociallink .= '<span class="img">
                                    <a href="' . $facebookLink . '" target="_blank" ><img src="' . $mediaUrl . 'comingsoon/facebook.png' . '"/></a>
                                </span>';
                }
                if ($googleplusLink != '') {
                    $sociallink .= '<span class="img">
                                   <a href="' . $googleplusLink . '" target="_blank" ><img src="' . $mediaUrl . 'comingsoon/googleplus.png' . '"/></a>
                                </span>';
                }
                if ($youtubeLink != '') {
                    $sociallink .= '<span class="img">
                                <a href="' . $youtubeLink . '" target="_blank" ><img src="' . $mediaUrl . 'comingsoon/youtube.png' . '"/></a>
                                </span>';
                }
                if ($linkedinLink != '') {
                    $sociallink .= '<span class="img">
                                     <a href="' . $linkedinLink . '" target="_blank" ><img src="' . $mediaUrl . 'comingsoon/linkedin.png' . '"/></a>
                                </span>';
                }
                if ($twitterLink != '') {
                    $sociallink .= '<span class="img">
                                      <a href="' . $twitterLink . '" target="_blank" ><img src="' . $mediaUrl . 'comingsoon/twitter.png' . '"/></a>
                                </span>';
                }
                if ($instagramLink != '') {
                    $sociallink .= '<span class="img">
                                    <a href="' . $instagramLink . '" target="_blank" ><img src="' . $mediaUrl . 'comingsoon/Instagram.png' . '"/></a>
                                </span>';
                }
                if ($pinterestLink != '') {
                    $sociallink .= '<span class="img">
                                      <a href="' . $pinterestLink . '" target="_blank" ><img src="' . $mediaUrl . 'comingsoon/pinterest.png' . '"/></a>
                                </span>';
                }
                $sociallink .= '</div>';
                $layoutHtml = str_replace("{sociallink}", $sociallink, $layoutHtml);
            } else {
                $layoutHtml = str_replace("{sociallink}", '', $layoutHtml);
            }

        }
        $this->helper->setErrorHtml($layoutHtml);


    }


    public function getSocialLink($facebookLink, $googleplusLink, $youtubeLink, $linkedinLink, $twitterLink, $instagramLink, $pinterestLink)
    {
        $sociallink = '<div class="text-center social-media">';
        $sociallink .= '<ul class="clearfix">';
        if ($facebookLink != '') {
            $sociallink .= '<li><a href="' . $facebookLink . '" target="_blank" ><em class="fa fa-facebook-f"></em></a></li>';
        }
        if ($googleplusLink != '') {
            $sociallink .= '<li><a href="' . $googleplusLink . '" target="_blank" ><em class="fa fa-google-plus"></em></a></li>';
        }
        if ($youtubeLink != '') {
            $sociallink .= '<li><a href="' . $youtubeLink . '" target="_blank" ><em class="fa fa-youtube-play"></em></a></li>';
        }
        if ($linkedinLink != '') {
            $sociallink .= '<li><a href="' . $linkedinLink . '" target="_blank" ><em class="fa fa-linkedin"></em></a></li>';
        }
        if ($twitterLink != '') {
            $sociallink .= '<li><a href="' . $twitterLink . '" target="_blank" ><em class="fa fa-twitter"></em></a></li>';
        }
        if ($instagramLink != '') {
            $sociallink .= '<li><a href="' . $instagramLink . '" target="_blank" ><em class="fa fa-instagram"></em></a></li>';
        }
        if ($pinterestLink != '') {
            $sociallink .= '<li><a href="' . $pinterestLink . '" target="_blank" ><em class="fa fa-pinterest-p"></em></a></li>';
        }
        $sociallink .= '</ul>';
        $sociallink .= '</div>';
        return $sociallink;
    }
}
