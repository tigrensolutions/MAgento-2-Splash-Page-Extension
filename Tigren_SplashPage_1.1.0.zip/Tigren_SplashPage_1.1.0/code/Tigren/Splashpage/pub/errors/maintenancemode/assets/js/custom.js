"use strict";

// Window Ready
$(document).ready(function(){
	FullSectionHeight(); // FullSectionHeight function call
	
	$('input, textarea').placeholder(); // For placeholder
	$.validate(); // Form validate
	
	$("#countdown").countdown({ // Counter timer
		date: "15 september 2017 12:00:00", // Enter new date here
		format: "on"
	},
	function() {
		// callback function
	});
	
	$('a.scroll-next').on('click', function(event) {
		var $anchor = $(this);
		$($anchor.attr('href')).removeClass("full-top")
	
		event.preventDefault();
	});
	
	$(".close-section").on('click', function(event) {
		$(this).closest(".section-block").addClass("full-top");
	});
	
	$(".banner-scroll-next").on('click', function(event) {
		$("#countdown").addClass("count-opacity");
	});
	
	$(".subscription-section .close-section").on('click', function(event) {
		$("#countdown").removeClass("count-opacity");
	});
});

// Window Resize
$(window).resize(function(){
	FullSectionHeight(); // FullSectionHeight function call
});

function FullSectionHeight(){
	var winHeight=$(window).height();
	$(".section-overlay,body").css('height',winHeight +'px');
}